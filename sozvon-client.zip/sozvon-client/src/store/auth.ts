// src/store/auth.ts

import { create } from 'zustand'
import { authApi } from '../api/auth'
import { storage } from '../services/storage'
import { getLoginFromToken } from '../utils/token'

interface AuthState {
  token: string | null
  login: string | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null
  
  login: (login: string, password: string) => Promise<void>
  register: (login: string, password: string) => Promise<void>
  logout: () => void
  initialize: () => void
}

export const useAuthStore = create<AuthState>((set) => ({
  token: null,
  login: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,
  
  login: async (loginValue: string, password: string) => {
    set({ isLoading: true, error: null })
    
    try {
      const response = await authApi.login({ 
        login: loginValue, 
        password 
      })
      
      storage.setToken(response.token)
      const userLogin = getLoginFromToken(response.token)
      
      set({
        token: response.token,
        login: userLogin,
        isAuthenticated: true,
        isLoading: false,
      })
    } catch (error: any) {
      set({
        error: error.message || 'Login failed',
        isLoading: false,
      })
      throw error
    }
  },
  
  register: async (loginValue: string, password: string) => {
    set({ isLoading: true, error: null })
    
    try {
      const response = await authApi.register({ 
        login: loginValue, 
        password 
      })
      
      storage.setToken(response.token)
      const userLogin = getLoginFromToken(response.token)
      
      set({
        token: response.token,
        login: userLogin,
        isAuthenticated: true,
        isLoading: false,
      })
    } catch (error: any) {
      set({
        error: error.message || 'Registration failed',
        isLoading: false,
      })
      throw error
    }
  },
  
  logout: () => {
    storage.removeToken()
    set({
      token: null,
      login: null,
      isAuthenticated: false,
      error: null,
    })
  },
  
  initialize: () => {
    const token = storage.getToken()
    
    if (token) {
      const userLogin = getLoginFromToken(token)
      set({
        token,
        login: userLogin,
        isAuthenticated: true,
      })
    }
  },
}))