// src/store/chats.ts

import { create } from 'zustand'
import type { Chat, Message } from '../types/models'
import { chatsApi } from '../api/chats'

interface ChatsState {
  chats: Chat[]
  messages: Record<string, Message[]>
  isLoading: boolean
  error: string | null
  
  loadChats: () => Promise<void>
  loadMessages: (chatId: string) => Promise<void>
  addMessage: (chatId: string, message: Message) => void
  addChat: (chat: Chat) => void
  clearMessages: (chatId: string) => void
}

export const useChatsStore = create<ChatsState>((set, get) => ({
  chats: [],
  messages: {},
  isLoading: false,
  error: null,
  
  loadChats: async () => {
    set({ isLoading: true, error: null })
    
    try {
      const chats = await chatsApi.getChats()
      set({ chats, isLoading: false })
    } catch (error: any) {
      set({ 
        error: error.message || 'Failed to load chats',
        isLoading: false 
      })
    }
  },
  
  loadMessages: async (chatId: string) => {
    set({ isLoading: true, error: null })
    
    try {
      const messages = await chatsApi.getMessages(chatId)
      set(state => ({
        messages: {
          ...state.messages,
          [chatId]: messages,
        },
        isLoading: false,
      }))
    } catch (error: any) {
      set({ 
        error: error.message || 'Failed to load messages',
        isLoading: false 
      })
    }
  },
  
  addMessage: (chatId: string, message: Message) => {
    set(state => ({
      messages: {
        ...state.messages,
        [chatId]: [...(state.messages[chatId] || []), message],
      },
    }))
  },
  
  addChat: (chat: Chat) => {
    set(state => ({
      chats: [chat, ...state.chats],
    }))
  },
  
  clearMessages: (chatId: string) => {
    set(state => ({
      messages: {
        ...state.messages,
        [chatId]: [],
      },
    }))
  },
}))