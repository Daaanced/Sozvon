// src/store/users.ts

import { create } from 'zustand'
import type { User } from '../types/models'
import { usersApi } from '../api/users'

interface UsersState {
  users: Record<string, User>
  isLoading: boolean
  error: string | null
  
  loadUser: (login: string) => Promise<User>
  getUser: (login: string) => User | null
  setUser: (login: string, user: User) => void
}

export const useUsersStore = create<UsersState>((set, get) => ({
  users: {},
  isLoading: false,
  error: null,
  
  loadUser: async (login: string) => {
    // Check cache first
    const cached = get().users[login]
    if (cached) {
      return cached
    }
    
    set({ isLoading: true, error: null })
    
    try {
      const user = await usersApi.getUser(login)
      set(state => ({
        users: {
          ...state.users,
          [login]: user,
        },
        isLoading: false,
      }))
      return user
    } catch (error: any) {
      set({ 
        error: error.message || 'Failed to load user',
        isLoading: false 
      })
      throw error
    }
  },
  
  getUser: (login: string) => {
    return get().users[login] || null
  },
  
  setUser: (login: string, user: User) => {
    set(state => ({
      users: {
        ...state.users,
        [login]: user,
      },
    }))
  },
}))