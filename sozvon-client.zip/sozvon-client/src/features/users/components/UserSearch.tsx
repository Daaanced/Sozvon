// src/features/users/components/UserSearch.tsx

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { usersApi } from '../../../api/users'
import { chatsApi } from '../../../api/chats'
import { useAuthStore } from '../../../store/auth'
import type { User } from '../../../types/models'

export function UserSearch() {
  const [query, setQuery] = useState('')
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const navigate = useNavigate()
  const myLogin = useAuthStore(state => state.login)
  
  const handleSearch = async () => {
    if (!query.trim()) return
    
    setLoading(true)
    setError('')
    setUser(null)
    
    try {
      const result = await usersApi.searchUser(query)
      setUser(result)
    } catch (err: any) {
      setError(err.message || 'User not found')
    } finally {
      setLoading(false)
    }
  }
  
  const handleCreateChat = async () => {
    if (!user || !myLogin) return
    
    try {
      const chat = await chatsApi.createChat({
        from: myLogin,
        to: user.login,
      })
      
      navigate(`/app/chats/${chat.id}`)
    } catch (err) {
      console.error('Failed to create chat:', err)
    }
  }
  
  return (
    <div>
      <h3>Search Users</h3>
      
      <div>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          placeholder="Enter username..."
        />
        <button onClick={handleSearch} disabled={loading}>
          Search
        </button>
      </div>
      
      {loading && <p>Searching...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}
      
      {user && (
        <div style={{
          border: '1px solid #ccc',
          padding: '10px',
          marginTop: '10px',
        }}>
          <div>
            <strong>{user.name}</strong>
            <br />
            <small>@{user.login}</small>
          </div>
          <button onClick={handleCreateChat}>
            Start Chat
          </button>
        </div>
      )}
    </div>
  )
}
