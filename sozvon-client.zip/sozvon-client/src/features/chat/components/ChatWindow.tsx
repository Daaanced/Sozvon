// src/features/chat/components/ChatWindow.tsx

import { useState } from 'react'
import { useChat } from '../../../hooks/useChat'

interface ChatWindowProps {
  chatId: string
}

export function ChatWindow({ chatId }: ChatWindowProps) {
  const [text, setText] = useState('')
  const { messages, sendMessage } = useChat(chatId)
  
  const handleSend = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!text.trim()) return
    
    sendMessage(text)
    setText('')
  }
  
  return (
    <div>
      <h3>Chat: {chatId}</h3>
      
      <div style={{ 
        height: '400px', 
        overflowY: 'auto',
        border: '1px solid #ccc',
        padding: '10px',
        marginBottom: '10px'
      }}>
        {messages.map(msg => (
          <div key={msg.id} style={{ marginBottom: '8px' }}>
            <strong>{msg.from}:</strong> {msg.text}
            <br />
            <small>{new Date(msg.createdAt).toLocaleTimeString()}</small>
          </div>
        ))}
      </div>
      
      <form onSubmit={handleSend}>
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Type a message..."
          style={{ width: '80%' }}
        />
        <button type="submit">Send</button>
      </form>
    </div>
  )
}
