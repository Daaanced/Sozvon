// src/features/chat/components/ChatList.tsx

import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useChatsStore } from '../../../store/chats'
import { useUsersStore } from '../../../store/users'
import { useAuthStore } from '../../../store/auth'
import { useWebSocket } from '../../../hooks/useWebSocket'

export function ChatList() {
  const navigate = useNavigate()
  const myLogin = useAuthStore(state => state.login)
  const { chats, loadChats } = useChatsStore()
  const { loadUser, getUser } = useUsersStore()
  const { on } = useWebSocket()
  
  useEffect(() => {
    loadChats()
  }, [loadChats])
  
  useEffect(() => {
    // Listen for new chats
    const unsubscribe = on('chat:created', () => {
      loadChats()
    })
    
    return unsubscribe
  }, [on, loadChats])
  
  useEffect(() => {
    // Load user info for all chat members
    chats.forEach(chat => {
      chat.members.forEach(member => {
        if (member !== myLogin) {
          loadUser(member).catch(console.error)
        }
      })
    })
  }, [chats, myLogin, loadUser])
  
  return (
    <div>
      <h3>Chats</h3>
      
      {chats.length === 0 && <p>No chats yet</p>}
      
      {chats.map(chat => {
        const otherMember = chat.members.find(m => m !== myLogin)
        const user = otherMember ? getUser(otherMember) : null
        
        return (
          <div
            key={chat.id}
            onClick={() => navigate(`/app/chats/${chat.id}`)}
            style={{
              padding: '10px',
              border: '1px solid #ccc',
              marginBottom: '5px',
              cursor: 'pointer',
            }}
          >
            <div>
              <strong>{user?.name || otherMember}</strong>
            </div>
            {chat.lastMessage && (
              <div style={{ fontSize: '0.9em', color: '#666' }}>
                {chat.lastMessage}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
