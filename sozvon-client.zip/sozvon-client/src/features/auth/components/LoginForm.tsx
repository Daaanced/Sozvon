// src/features/auth/components/LoginForm.tsx

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../../hooks/useAuth'

export function LoginForm() {
  const [loginValue, setLoginValue] = useState('')
  const [password, setPassword] = useState('')
  const { login, isLoading, error } = useAuth()
  const navigate = useNavigate()
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      await login(loginValue, password)
      navigate('/app')
    } catch (err) {
      // Error is handled in store
    }
  }
  
  return (
    <div>
      <h2>Login</h2>
      
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Login"
          value={loginValue}
          onChange={(e) => setLoginValue(e.target.value)}
          disabled={isLoading}
        />
        
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          disabled={isLoading}
        />
        
        <button type="submit" disabled={isLoading}>
          {isLoading ? 'Loading...' : 'Login'}
        </button>
        
        {error && <p style={{ color: 'red' }}>{error}</p>}
      </form>
    </div>
  )
}
