// src/api/chats.ts

import { api } from './client'
import type { Chat, Message, CreateChatRequest } from '../types/models'

export const chatsApi = {
  getChats: () => 
    api.get<Chat[]>('/chats'),
  
  getMessages: (chatId: string, limit = 50, offset = 0) => 
    api.get<Message[]>(`/chats/${chatId}/messages?limit=${limit}&offset=${offset}`),
  
  getChatInfo: (chatId: string) =>
    api.get<{
      chatId: string
      members: string[]
      onlineStatus: Record<string, boolean>
    }>(`/chats/${chatId}`),
  
  createChat: (data: CreateChatRequest) => 
    api.post<Chat>('/chats/create', data),
}