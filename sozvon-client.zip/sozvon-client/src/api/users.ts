// src/api/users.ts

import { api } from './client'
import type { User } from '../types/models'

export const usersApi = {
  getUser: (login: string) => 
    api.get<User>(`/users/${encodeURIComponent(login)}`),
  
  getUsers: () => 
    api.get<User[]>('/users'),
  
  searchUser: (login: string) => 
    api.get<User>(`/users/${encodeURIComponent(login)}`),
}