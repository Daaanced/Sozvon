// src/services/storage.ts

class StorageService {
  private prefix = 'sozvon_'
  
  setToken(token: string): void {
    localStorage.setItem(`${this.prefix}token`, token)
  }
  
  getToken(): string | null {
    return localStorage.getItem(`${this.prefix}token`)
  }
  
  removeToken(): void {
    localStorage.removeItem(`${this.prefix}token`)
  }
  
  setItem(key: string, value: any): void {
    try {
      const serialized = JSON.stringify(value)
      localStorage.setItem(`${this.prefix}${key}`, serialized)
    } catch (error) {
      console.error('Storage: Failed to set item', error)
    }
  }
  
  getItem<T>(key: string): T | null {
    try {
      const item = localStorage.getItem(`${this.prefix}${key}`)
      return item ? JSON.parse(item) : null
    } catch (error) {
      console.error('Storage: Failed to get item', error)
      return null
    }
  }
  
  removeItem(key: string): void {
    localStorage.removeItem(`${this.prefix}${key}`)
  }
  
  clear(): void {
    Object.keys(localStorage)
      .filter(key => key.startsWith(this.prefix))
      .forEach(key => localStorage.removeItem(key))
  }
}

export const storage = new StorageService()