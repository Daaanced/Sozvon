// src/services/websocket.ts

import { config } from '../config/constants'
import type { WSEvent, WSEventType, MessageHandler } from '../types/ws'

export class WebSocketService {
  private socket: WebSocket | null = null
  private listeners = new Map<WSEventType, Set<MessageHandler<any>>>()
  private reconnectAttempts = 0
  private reconnectTimer: number | null = null
  private isConnected = false
  
  constructor(private token: string) {}
  
  connect() {
    if (this.socket && this.isConnected) {
      return
    }
    
    try {
      this.socket = new WebSocket(
        `${config.wsUrl}/ws?token=${this.token}`
      )
      
      this.socket.onopen = this.handleOpen.bind(this)
      this.socket.onclose = this.handleClose.bind(this)
      this.socket.onerror = this.handleError.bind(this)
      this.socket.onmessage = this.handleMessage.bind(this)
      
    } catch (error) {
      console.error('[WS] Connection error:', error)
      this.scheduleReconnect()
    }
  }
  
  private handleOpen() {
    console.log('[WS] Connected')
    this.isConnected = true
    this.reconnectAttempts = 0
  }
  
  private handleClose() {
    console.log('[WS] Disconnected')
    this.isConnected = false
    this.socket = null
    this.scheduleReconnect()
  }
  
  private handleError(error: Event) {
    console.error('[WS] Error:', error)
  }
  
  private handleMessage(event: MessageEvent) {
    try {
      const message: WSEvent = JSON.parse(event.data)
      this.emit(message)
    } catch (error) {
      console.error('[WS] Failed to parse message:', error)
    }
  }
  
  private scheduleReconnect() {
    if (this.reconnectAttempts >= config.ws.maxReconnectAttempts) {
      console.error('[WS] Max reconnect attempts reached')
      return
    }
    
    if (this.reconnectTimer) {
      return
    }
    
    const delay = config.ws.reconnectDelay * Math.pow(2, this.reconnectAttempts)
    console.log(`[WS] Reconnecting in ${delay}ms...`)
    
    this.reconnectTimer = window.setTimeout(() => {
      this.reconnectTimer = null
      this.reconnectAttempts++
      this.connect()
    }, delay)
  }
  
  send(data: any) {
    if (!this.socket || !this.isConnected) {
      console.warn('[WS] Cannot send: not connected')
      return false
    }
    
    try {
      this.socket.send(JSON.stringify(data))
      return true
    } catch (error) {
      console.error('[WS] Send error:', error)
      return false
    }
  }
  
  on<T extends WSEventType>(
    event: T,
    handler: MessageHandler<Extract<WSEvent, { event: T }>['data']>
  ): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set())
    }
    
    this.listeners.get(event)!.add(handler)
    
    return () => {
      this.listeners.get(event)?.delete(handler)
    }
  }
  
  private emit(event: WSEvent) {
    const handlers = this.listeners.get(event.event)
    if (handlers) {
      handlers.forEach(handler => {
        try {
          handler(event.data)
        } catch (error) {
          console.error(`[WS] Handler error for ${event.event}:`, error)
        }
      })
    }
  }
  
  disconnect() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer)
      this.reconnectTimer = null
    }
    
    if (this.socket) {
      this.socket.close()
      this.socket = null
    }
    
    this.isConnected = false
    this.listeners.clear()
  }
  
  getConnectionState(): 'connected' | 'disconnected' | 'connecting' {
    if (this.isConnected) return 'connected'
    if (this.socket) return 'connecting'
    return 'disconnected'
  }
}

let wsInstance: WebSocketService | null = null

export function getWebSocketService(token: string): WebSocketService {
  if (!wsInstance) {
    wsInstance = new WebSocketService(token)
    wsInstance.connect()
  }
  return wsInstance
}

export function disconnectWebSocket() {
  if (wsInstance) {
    wsInstance.disconnect()
    wsInstance = null
  }
}