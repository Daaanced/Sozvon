// src/types/models.ts

export interface User {
  id: number
  login: string
  name: string
  email: string
  info: string
  picture: string
  created_at: string
  updated_at: string
}

export interface Chat {
  id: string
  chatId: string
  members: string[]
  active: boolean
  lastMessage?: string
  unreadCount?: number
  updatedAt?: string
}

export interface Message {
  id: string
  chatId: string
  from: string
  text: string
  createdAt: string
}

export interface AuthResponse {
  token: string
  expiresIn: number
  tokenType: string
}

export interface CreateChatRequest {
  from: string
  to: string
}