// src/types/ws.ts

export type WSEventType = 
  | 'message:new'
  | 'message:send'
  | 'chat:created'
  | 'typing:start'
  | 'typing:stop'
  | 'error'

export interface WSMessageData {
  id?: string
  chatId: string
  from: string
  text: string
  createdAt?: string
}

export interface WSTypingData {
  chatId: string
  from: string
}

export interface WSChatCreatedData {
  chatId: string
}

export interface WSErrorData {
  error: string
  message: string
}

export type WSEvent = 
  | { event: 'message:new'; data: WSMessageData }
  | { event: 'message:send'; data: { chatId: string; text: string } }
  | { event: 'chat:created'; data: WSChatCreatedData }
  | { event: 'typing:start'; data: WSTypingData }
  | { event: 'typing:stop'; data: WSTypingData }
  | { event: 'error'; data: WSErrorData }

export type MessageHandler<T = any> = (data: T) => void