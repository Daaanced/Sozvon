// src/hooks/useAuth.ts

import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '../store/auth'

export function useAuth() {
  const navigate = useNavigate()
  const { 
    token, 
    login, 
    isAuthenticated, 
    isLoading, 
    error,
    login: loginAction,
    register: registerAction,
    logout: logoutAction,
    initialize,
  } = useAuthStore()
  
  useEffect(() => {
    initialize()
  }, [initialize])
  
  const logout = () => {
    logoutAction()
    navigate('/')
  }
  
  return {
    token,
    login,
    isAuthenticated,
    isLoading,
    error,
    login: loginAction,
    register: registerAction,
    logout,
  }
}