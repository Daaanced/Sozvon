// src/hooks/useWebSocket.ts

import { useEffect, useState } from 'react'
import { useAuthStore } from '../store/auth'
import { getWebSocketService, disconnectWebSocket } from '../services/websocket'
import type { WSEventType, MessageHandler } from '../types/ws'

export function useWebSocket() {
  const token = useAuthStore(state => state.token)
  const [ws, setWs] = useState<ReturnType<typeof getWebSocketService> | null>(null)
  const [connectionState, setConnectionState] = useState<'connected' | 'disconnected' | 'connecting'>('disconnected')
  
  useEffect(() => {
    if (!token) {
      disconnectWebSocket()
      setWs(null)
      return
    }
    
    const service = getWebSocketService(token)
    setWs(service)
    
    // Update connection state periodically
    const interval = setInterval(() => {
      setConnectionState(service.getConnectionState())
    }, 1000)
    
    return () => {
      clearInterval(interval)
      disconnectWebSocket()
    }
  }, [token])
  
  const sendMessage = (data: any) => {
    if (ws) {
      ws.send(data)
    }
  }
  
  const on = <T extends WSEventType>(
    event: T,
    handler: MessageHandler<any>
  ): (() => void) => {
    if (ws) {
      return ws.on(event, handler)
    }
    return () => {}
  }
  
  return {
    sendMessage,
    on,
    connectionState,
    isConnected: connectionState === 'connected',
  }
}