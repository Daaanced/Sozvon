// src/hooks/useChat.ts

import { useEffect } from 'react'
import { useChatsStore } from '../store/chats'
import { useWebSocket } from './useWebSocket'
import type { Message } from '../types/models'

export function useChat(chatId: string) {
  const { messages, loadMessages, addMessage, clearMessages } = useChatsStore()
  const { sendMessage: wsSend, on } = useWebSocket()
  
  const chatMessages = messages[chatId] || []
  
  useEffect(() => {
    // Load messages when chat changes
    clearMessages(chatId)
    loadMessages(chatId)
  }, [chatId, loadMessages, clearMessages])
  
  useEffect(() => {
    // Listen for new messages
    const unsubscribe = on('message:new', (data) => {
      if (data.chatId === chatId) {
        const message: Message = {
          id: data.id || crypto.randomUUID(),
          chatId: data.chatId,
          from: data.from,
          text: data.text,
          createdAt: data.createdAt || new Date().toISOString(),
        }
        addMessage(chatId, message)
      }
    })
    
    return unsubscribe
  }, [chatId, on, addMessage])
  
  const sendMessage = (text: string) => {
    wsSend({
      event: 'message:send',
      data: {
        chatId,
        text,
      },
    })
  }
  
  return {
    messages: chatMessages,
    sendMessage,
  }
}