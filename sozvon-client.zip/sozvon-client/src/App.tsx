// src/App.tsx

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './hooks/useAuth'
import { LoginForm } from './features/auth/components/LoginForm'
import { ChatList } from './features/chat/components/ChatList'
import { ChatWindow } from './features/chat/components/ChatWindow'
import { UserSearch } from './features/users/components/UserSearch'

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuth()
  
  if (!isAuthenticated) {
    return <Navigate to="/" replace />
  }
  
  return <>{children}</>
}

function AppLayout() {
  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <div style={{ 
        width: '300px', 
        borderRight: '1px solid #ccc',
        padding: '10px',
        overflowY: 'auto'
      }}>
        <ChatList />
      </div>
      
      <div style={{ flex: 1, padding: '20px' }}>
        <Routes>
          <Route index element={<UserSearch />} />
          <Route path="chats/:chatId" element={<ChatPage />} />
        </Routes>
      </div>
    </div>
  )
}

function ChatPage() {
  const params = new URLSearchParams(window.location.search)
  const chatId = window.location.pathname.split('/').pop()
  
  if (!chatId) {
    return <div>Select a chat</div>
  }
  
  return <ChatWindow chatId={chatId} />
}

export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LoginForm />} />
        
        <Route 
          path="/app/*" 
          element={
            <ProtectedRoute>
              <AppLayout />
            </ProtectedRoute>
          } 
        />
      </Routes>
    </BrowserRouter>
  )
}
