// src/config/constants.ts

export const config = {
  apiUrl: import.meta.env.VITE_API_URL || 'http://176.51.121.88:8080',
  wsUrl: import.meta.env.VITE_WS_URL || 'ws://176.51.121.88:8080',
  
  ws: {
    reconnectDelay: 1000,
    maxReconnectAttempts: 5,
    pingInterval: 30000,
  },
  
  api: {
    timeout: 10000,
  },
} as const