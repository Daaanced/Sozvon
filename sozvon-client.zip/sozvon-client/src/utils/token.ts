// src/utils/token.ts

export interface TokenPayload {
  login: string
  exp: number
  iat: number
  nbf?: number
  iss?: string
  sub?: string
}

export function parseToken(token: string): TokenPayload | null {
  try {
    const parts = token.split('.')
    if (parts.length !== 3) {
      return null
    }
    
    const payload = parts[1]
    const decoded = atob(payload.replace(/-/g, '+').replace(/_/g, '/'))
    return JSON.parse(decoded)
  } catch (error) {
    console.error('Failed to parse token:', error)
    return null
  }
}

export function isTokenExpired(token: string): boolean {
  const payload = parseToken(token)
  if (!payload || !payload.exp) {
    return true
  }
  
  // exp is in seconds, Date.now() is in milliseconds
  return payload.exp * 1000 < Date.now()
}

export function getLoginFromToken(token: string): string | null {
  const payload = parseToken(token)
  return payload?.login || null
}